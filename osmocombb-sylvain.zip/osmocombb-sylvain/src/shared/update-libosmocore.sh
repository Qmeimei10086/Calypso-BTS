#!/bin/sh

(cd ../.. && git subtree pull --prefix=src/shared/libosmocore git://git.osmocom.org/libosmocore.git master)
