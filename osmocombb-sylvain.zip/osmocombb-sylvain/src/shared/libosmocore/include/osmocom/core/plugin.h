#ifndef _OSMO_PLUGIN_H
#define _OSMO_PLUGIN_H

int osmo_plugin_load_all(const char *directory);

#endif
